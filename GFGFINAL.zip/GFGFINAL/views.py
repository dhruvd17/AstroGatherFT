from flask import Blueprint, render_template, request, jsonify, redirect, url_for

views=Blueprint(__name__,"views")

@views.route("/login")
def login():
    return render_template("login.html")

@views.route("/signup")
def signup():
    return render_template("signup.html")
    
@views.route("/feed")
def feed():
    return render_template("feed.html")

@views.route("/community")
def comm():
    return render_template("comm.html")

@views.route("/home")
def home():
    return render_template("home.html")

@views.route("/")
def home2():
    return render_template("home.html")

@views.route("/forum")
def forum():
    return render_template("forum.html")

@views.route("/dash")
def dash():
    return render_template("dash.html")



@views.route("/go-to-home")
def go_to_home():
    return redirect(url_for("views.login"))