const existingUsernames = ['user1', 'user2']; // Example of existing usernames

document.getElementById('signupForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const dob = new Date(document.getElementById('dob').value);
    const today = new Date();
    const age = today.getFullYear() - dob.getFullYear();
    const messageElement = document.getElementById('message');
    const successLink = document.getElementById('successLink');

    // Reset the message and link visibility
    messageElement.innerText = '';
    successLink.style.display = 'none';

    // Check if username already exists
    if (existingUsernames.includes(username)) {
        messageElement.innerText = 'Username already exists.';
        messageElement.style.color = 'red';
        return;
    }

    // Check if user is at least 18 years old
    if (age < 18 || (today.getMonth() < dob.getMonth()) || (today.getMonth() === dob.getMonth() && today.getDate() < dob.getDate())) {
        messageElement.innerText = 'You must be at least 18 years old.';
        messageElement.style.color = 'red';
        return;
    }

    // Check if passwords match
    if (password !== confirmPassword) {
        messageElement.innerText = 'Passwords do not match.';
        messageElement.style.color = 'red';
        return;
    }

    // If all checks pass
    messageElement.innerText = 'Sign up successful!';
    messageElement.style.color = 'green'; // Change to green for success
    successLink.style.display = 'block'; // Show the success link

    // Store user details in localStorage
    const users = JSON.parse(localStorage.getItem('users')) || [];
    users.push({ username: username, password: password, dob: dob.toISOString() });
    localStorage.setItem('users', JSON.stringify(users));

    // Redirect to login page when the link is clicked
    successLink.addEventListener('click', function(e) {
        e.preventDefault(); // Prevent default anchor behavior
        window.location.href = '/login'; // Redirect to the login page
    });
});
