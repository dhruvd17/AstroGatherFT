// Redirect on Get Started button click
document.querySelector('.cta-button').addEventListener('click', function(e) {
    e.preventDefault(); // Prevent the default anchor behavior
    window.location.href = '/signup'; // Change to your signup route
});

// Redirect on Register button click
document.querySelector('.register-section button').addEventListener('click', function(e) {
    e.preventDefault(); // Prevent the default form submission
    window.location.href = '/signup'; // Change to your signup route
});
