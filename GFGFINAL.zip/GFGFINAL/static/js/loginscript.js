document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const messageElement = document.getElementById('message');

    // Retrieve stored users from localStorage
    const users = JSON.parse(localStorage.getItem('users')) || [];
    // Find user with matching username
    const user = users.find(u => u.username === username);

    // Check if user exists and password matches
    if (user && user.password === password) {
        messageElement.innerText = 'Login successful!';
        messageElement.style.color = 'green';
        // Example code to save username after successful login
        localStorage.setItem('username', username); // Replace 'yourUsername' with the actual username

        // Redirect to dash.html after successful login
        setTimeout(() => {
            window.location.href = '/dash';
        }, 1000); // Adding a short delay for user feedback
    } else {
        messageElement.innerText = 'Invalid username or password.';
        messageElement.style.color = 'red';
    }
});

// Redirect to signup page when "Sign Up" button is clicked
document.getElementById('signupButton').addEventListener('click', function() {
    window.location.href = '/signup';
});
