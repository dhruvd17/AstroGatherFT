document.getElementById('postForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const postContent = document.getElementById('postContent').value;
    const postsList = document.getElementById('postsList');

    // Create a new post element
    const postElement = document.createElement('div');
    postElement.className = 'post';
    postElement.innerText = postContent;

    // Append the new post to the posts list
    postsList.prepend(postElement);

    // Clear the textarea
    document.getElementById('postContent').value = '';
});
